CARA MENDAPATKAN APK (tanpa Android Studio)
1. Buat akun github.com (gratis) lalu buat repository baru (Private tidak masalah).
2. Upload SEMUA isi folder ini (termasuk folder .github) ke repository itu.
   (Di HP/PC: "Add file" > "Upload files". Folder .github harus ikut terunggah.)
3. Buka tab "Actions" > workflow "Build APK" > tunggu hijau (3-6 menit).
   Jika tidak jalan otomatis, klik "Run workflow".
4. Buka hasil run > bagian Artifacts > unduh "AnemoAlarm-apk" (zip), ekstrak, kirim app-debug.apk ke HP.
5. Install (izinkan "Install dari sumber tidak dikenal"). Beri izin kamera & notifikasi.

ALTERNATIF: buka folder ini di Android Studio > Build > Build APK(s).

TIPS: Pasang HP tegak & stabil, colok charger, Setelan > Aplikasi > Alarm Anemometer > Baterai > "Tanpa batasan".
