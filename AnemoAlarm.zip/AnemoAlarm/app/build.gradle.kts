plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "com.anemo.alarm"
    compileSdk = 34
    defaultConfig { applicationId = "com.anemo.alarm"; minSdk = 26; targetSdk = 34; versionCode = 1; versionName = "1.0" }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
dependencies {
    val c = "1.3.4"
    implementation("androidx.camera:camera-core:$c")
    implementation("androidx.camera:camera-camera2:$c")
    implementation("androidx.camera:camera-lifecycle:$c")
    implementation("androidx.camera:camera-view:$c")
    implementation("androidx.lifecycle:lifecycle-service:2.8.4")
}
