package com.anemo.alarm

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.*
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.camera.view.PreviewView

class MainActivity : Activity() {
    private lateinit var pv: PreviewView
    private lateinit var ov: View
    private lateinit var valTv: TextView
    private lateinit var root: LinearLayout

    private fun seek(init: Int, max: Int, cb: (Int) -> String) {
        val t = TextView(this); t.text = cb(init)
        val s = SeekBar(this); s.max = max; s.progress = init
        s.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(b: SeekBar?, p: Int, u: Boolean) { t.text = cb(p); ov.invalidate(); Cfg.save(this@MainActivity) }
            override fun onStartTrackingTouch(b: SeekBar?) {}
            override fun onStopTrackingTouch(b: SeekBar?) {}
        })
        root.addView(t); root.addView(s)
    }

    private fun btn(txt: String, f: () -> Unit) = Button(this).apply { text = txt; setOnClickListener { f() } }.also { root.addView(it) }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b); Cfg.load(this)
        root = LinearLayout(this); root.orientation = LinearLayout.VERTICAL; root.setPadding(24, 24, 24, 48)
        val w = resources.displayMetrics.widthPixels - 48
        val fr = FrameLayout(this); pv = PreviewView(this); fr.addView(pv)
        val paint = Paint().apply { color = Color.YELLOW; style = Paint.Style.STROKE; strokeWidth = 4f }
        ov = object : View(this) { override fun onDraw(c: Canvas) {
            val W = width.toFloat(); val H = height.toFloat()
            c.drawRect(Cfg.rx * W, Cfg.ry * H, (Cfg.rx + Cfg.rw).coerceAtMost(1f) * W, (Cfg.ry + Cfg.rh).coerceAtMost(1f) * H, paint) } }
        fr.addView(ov, ViewGroup.LayoutParams(-1, -1))
        root.addView(fr, LinearLayout.LayoutParams(w, w * 4 / 3))
        valTv = TextView(this).apply { textSize = 56f; gravity = android.view.Gravity.CENTER; text = "--" }; root.addView(valTv)
        btn("▶ Mulai Pantau") { start() }
        btn("🔕 Matikan Alarm") { Svc.inst?.stopAlarm() }
        btn("⏹ Berhenti Total") { stopService(Intent(this, Svc::class.java)); valTv.text = "--" }
        btn("Tes Alarm") { val s = Svc.inst; if (s != null) { s.startAlarm(); valTv.postDelayed({ s.stopAlarm() }, 2500) } else toast("Tekan Mulai dulu") }
        seek(Cfg.limit, 100) { Cfg.limit = it; "Alarm jika angka lebih dari: $it" }
        seek(Cfg.n - 1, 3) { Cfg.n = it + 1; "Jumlah digit: ${it + 1}" }
        root.addView(CheckBox(this).apply { text = "Digit terakhir desimal (÷10)"; isChecked = Cfg.dec
            setOnCheckedChangeListener { _, c -> Cfg.dec = c; Cfg.save(context) } })
        root.addView(CheckBox(this).apply { text = "Angka terang di latar gelap"; isChecked = Cfg.light
            setOnCheckedChangeListener { _, c -> Cfg.light = c; Cfg.save(context) } })
        seek((Cfg.rx * 100).toInt(), 95) { Cfg.rx = it / 100f; "Kotak kiri: $it%" }
        seek((Cfg.ry * 100).toInt(), 95) { Cfg.ry = it / 100f; "Kotak atas: $it%" }
        seek((Cfg.rw * 100).toInt(), 100) { Cfg.rw = maxOf(it, 5) / 100f; "Kotak lebar: $it%" }
        seek((Cfg.rh * 100).toInt(), 100) { Cfg.rh = maxOf(it, 5) / 100f; "Kotak tinggi: $it%" }
        root.addView(TextView(this).apply { text = "Atur kotak kuning agar menutupi angka saja (tiap digit sama lebar). Matikan penghemat baterai untuk aplikasi ini." })
        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun start() {
        val need = mutableListOf<String>()
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) need += Manifest.permission.CAMERA
        if (android.os.Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) need += Manifest.permission.POST_NOTIFICATIONS
        if (need.isNotEmpty()) { requestPermissions(need.toTypedArray(), 1); return }
        startForegroundService(Intent(this, Svc::class.java))
    }

    override fun onRequestPermissionsResult(rc: Int, p: Array<out String>, r: IntArray) {
        if (checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) start() else toast("Izin kamera diperlukan")
    }

    override fun onResume() { super.onResume(); Svc.surface = pv.surfaceProvider
        Svc.onValue = { s -> runOnUiThread { valTv.text = s } } }
    override fun onPause() { super.onPause(); Svc.surface = null; Svc.onValue = null }
}
