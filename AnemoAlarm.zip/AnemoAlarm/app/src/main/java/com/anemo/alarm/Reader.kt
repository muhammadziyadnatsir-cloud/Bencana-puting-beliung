package com.anemo.alarm

import android.content.Context
import java.nio.ByteBuffer

object Cfg {
    var n = 2; var dec = false; var light = false; var limit = 30
    var rx = .3f; var ry = .35f; var rw = .4f; var rh = .25f
    fun load(c: Context) { val p = c.getSharedPreferences("c", 0)
        n = p.getInt("n", 2); dec = p.getBoolean("dec", false); light = p.getBoolean("light", false); limit = p.getInt("limit", 30)
        rx = p.getFloat("rx", .3f); ry = p.getFloat("ry", .35f); rw = p.getFloat("rw", .4f); rh = p.getFloat("rh", .25f) }
    fun save(c: Context) { c.getSharedPreferences("c", 0).edit().putInt("n", n).putBoolean("dec", dec).putBoolean("light", light)
        .putInt("limit", limit).putFloat("rx", rx).putFloat("ry", ry).putFloat("rw", rw).putFloat("rh", rh).apply() }
}

object Reader {
    // segmen a..g : x0,y0,x1,y1 (relatif terhadap satu digit)
    private val SEG = arrayOf(
        floatArrayOf(.2f, .02f, .8f, .14f), floatArrayOf(.72f, .15f, .98f, .47f), floatArrayOf(.72f, .53f, .98f, .85f),
        floatArrayOf(.2f, .86f, .8f, .98f), floatArrayOf(.02f, .53f, .28f, .85f), floatArrayOf(.02f, .15f, .28f, .47f),
        floatArrayOf(.2f, .43f, .8f, .57f))
    private val PAT = mapOf("abcdef" to 0, "bc" to 1, "abdeg" to 2, "abcdg" to 3, "bcfg" to 4,
        "acdfg" to 5, "acdefg" to 6, "abc" to 7, "abcdefg" to 8, "abcdfg" to 9)

    private fun otsu(g: IntArray): Int {
        val h = IntArray(256); for (p in g) h[p]++
        var sum = 0L; for (i in 0..255) sum += i.toLong() * h[i]
        var sB = 0L; var wB = 0; var mx = 0.0; var t = 128
        for (i in 0..255) { wB += h[i]; if (wB == 0) continue; val wF = g.size - wB; if (wF == 0) break
            sB += i.toLong() * h[i]; val d = sB.toDouble() / wB - (sum - sB).toDouble() / wF
            val b = wB.toDouble() * wF * d * d; if (b > mx) { mx = b; t = i } }
        return t
    }

    /** Baca angka dari bidang Y (luminance) kamera. Null jika tidak terbaca. */
    fun read(buf: ByteBuffer, stride: Int, rw: Int, rh: Int, rot: Int): Double? {
        val n = Cfg.n; val cw = 40; val ch = 64; val W = cw * n
        val dw = if (rot % 180 == 0) rw else rh; val dh = if (rot % 180 == 0) rh else rw
        val g = IntArray(W * ch)
        for (j in 0 until ch) for (i in 0 until W) {
            val u = ((Cfg.rx + Cfg.rw * (i + .5f) / W) * dw).toInt().coerceIn(0, dw - 1)
            val v = ((Cfg.ry + Cfg.rh * (j + .5f) / ch) * dh).toInt().coerceIn(0, dh - 1)
            val x: Int; val y: Int
            when (rot) { 0 -> { x = u; y = v }; 90 -> { x = v; y = rh - 1 - u }
                180 -> { x = rw - 1 - u; y = rh - 1 - v }; else -> { x = rw - 1 - v; y = u } }
            g[j * W + i] = buf.get(y * stride + x).toInt() and 0xFF
        }
        val t = otsu(g)
        val on = BooleanArray(g.size) { if (Cfg.light) g[it] > t else g[it] < t }
        var out = ""; var started = false
        for (k in 0 until n) {
            var key = ""
            for (s in 0..6) { val q = SEG[s]; var c = 0; var a = 0
                for (y in (q[1] * ch).toInt() until Math.ceil((q[3] * ch).toDouble()).toInt())
                    for (x in (k * cw + q[0] * cw).toInt() until Math.ceil((k * cw + q[2] * cw).toDouble()).toInt()) { a++; if (on[y * W + x]) c++ }
                if (a > 0 && c.toFloat() / a > .5f) key += "abcdefg"[s] }
            if (key.isEmpty()) { if (started) return null; continue }
            val d = PAT[key] ?: return null
            started = true; out += d
        }
        if (!started) return null
        val v = out.toInt().toDouble()
        return if (Cfg.dec) v / 10 else v
    }
}
