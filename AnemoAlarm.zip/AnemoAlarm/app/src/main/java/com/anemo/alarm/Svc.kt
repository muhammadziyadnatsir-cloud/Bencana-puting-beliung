package com.anemo.alarm

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.*
import android.os.*
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleService
import java.util.concurrent.Executors
import kotlin.math.PI
import kotlin.math.sin

class Svc : LifecycleService() {
    companion object {
        var inst: Svc? = null
        var preview: Preview? = null
        var surface: Preview.SurfaceProvider? = null
            set(v) { field = v; preview?.setSurfaceProvider(v) }
        var onValue: ((String) -> Unit)? = null
    }

    private var hits = 0; private var silenced = false; private var last = 0L
    private var track: AudioTrack? = null; private var wl: PowerManager.WakeLock? = null
    private val exec = Executors.newSingleThreadExecutor(); private val main = Handler(Looper.getMainLooper())

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)
        if (inst != null) return START_STICKY
        inst = this
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel("mon", "Pemantauan", NotificationManager.IMPORTANCE_LOW))
        val pi = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, "mon").setContentTitle("Memantau anemometer")
            .setContentText("Alarm aktif jika angka melewati batas").setSmallIcon(android.R.drawable.ic_menu_camera)
            .setContentIntent(pi).setOngoing(true).build()
        startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA)
        wl = (getSystemService(Context.POWER_SERVICE) as PowerManager).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "anemo:mon").apply { acquire() }
        val fut = ProcessCameraProvider.getInstance(this)
        fut.addListener({
            val p = fut.get()
            val pr = Preview.Builder().build().also { it.setSurfaceProvider(surface); preview = it }
            val an = ImageAnalysis.Builder().setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST).build()
            an.setAnalyzer(exec) { img ->
                val now = System.currentTimeMillis()
                if (now - last > 300) { last = now
                    val y = img.planes[0]
                    val r = try { Reader.read(y.buffer, y.rowStride, img.width, img.height, img.imageInfo.rotationDegrees) } catch (e: Exception) { null }
                    main.post { handle(r) } }
                img.close()
            }
            p.unbindAll()
            p.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, pr, an)
        }, ContextCompat.getMainExecutor(this))
        return START_STICKY
    }

    private fun handle(v: Double?) {
        if (v == null) { hits = 0; onValue?.invoke("??"); return }
        onValue?.invoke(if (Cfg.dec) "%.1f".format(v) else v.toInt().toString())
        if (v > Cfg.limit) { hits++; if (hits >= 2 && !silenced) startAlarm() } else { hits = 0; silenced = false }
    }

    fun startAlarm() {
        if (track != null) return
        val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.setStreamVolume(AudioManager.STREAM_ALARM, am.getStreamMaxVolume(AudioManager.STREAM_ALARM), 0)
        val sr = 22050; val len = sr * 2; val buf = ShortArray(len); var ph = 0.0
        for (i in 0 until len) { val f = if ((i * 4 / len) % 2 == 0) 700.0 else 1300.0
            ph += 2 * PI * f / sr; buf[i] = (if (sin(ph) >= 0) 30000 else -30000).toShort() }
        val t = AudioTrack.Builder()
            .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
            .setAudioFormat(AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT).setSampleRate(sr).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
            .setBufferSizeInBytes(len * 2).setTransferMode(AudioTrack.MODE_STATIC).build()
        t.write(buf, 0, len); t.setLoopPoints(0, len, -1); t.play(); track = t
        (getSystemService(Context.VIBRATOR_SERVICE) as Vibrator).vibrate(VibrationEffect.createWaveform(longArrayOf(0, 500, 300), 0))
    }

    fun stopAlarm() {
        silenced = true
        track?.let { it.stop(); it.release() }; track = null
        (getSystemService(Context.VIBRATOR_SERVICE) as Vibrator).cancel()
    }

    override fun onDestroy() {
        stopAlarm(); preview = null; inst = null
        try { ProcessCameraProvider.getInstance(this).get().unbindAll() } catch (e: Exception) {}
        wl?.let { if (it.isHeld) it.release() }
        super.onDestroy()
    }
}
